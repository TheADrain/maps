===========================================
			Details			
===========================================
Version				: 1.1 (updated 09/01/2022)
Title 				: Fortress Interior
Filename 			: fortress.zip
Map name			: fortress.bsp 
Release Date 			: 01/01/2021
Author 				: Addy / TheADrain
Twitter				: @adraindev
Additional Credits	: Aleksander "Khreathor" Marhall (prototype.zip) could not build without it <3

===========================================
			Description		
===========================================

Single player map that takes the player through a large mountain fortress in the idbase style

This is my first single player map, I really hope you enjoy it :)
I would love any feedback on the design!

Thanks
~Addy 

===========================================
			Play Info			
===========================================
Single Player			: Yes
Cooperative Play		: No
2-4 Player Deathmatch 	: No
Difficulty Settings		: Easy/Medium/Hard

===========================================
			Included Files				
===========================================
fortress.bsp
fortress.lit
fortress.map
readme.txt

===========================================
			Construction				
===========================================
Editor Used		: Trenchbroom 2021.1 win32
Known bugs		: There are some secrets that intentionally do not have a secret trigger
				  
Tested With		: quakespasm-0.94.2_win64 / 2021 Bethesda Rerelease

===========================================
			Copyright Info				
===========================================

Authors MAY use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.