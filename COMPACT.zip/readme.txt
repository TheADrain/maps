===========================================
=== 		Details						===
===========================================
Title 				: Compact
Filename 			: compact.zip
Map name			: compact.bsp 
Release Date 			: unreleased test level
Author 				: Addy / TheADrain
Twitter				: @adraindev
Additional Credits	: Aleksander "Khreathor" Marhall (prototype.zip) could not build without it <3

===========================================
=== 		Description					===
===========================================
A small single player level built within a 1024 unit cube as a challenge,
currently only in greybox stage, there may be bugs


===========================================
=== 		Play Info			===
===========================================
Primary Design		: Single player
Cooperative Play		: No
Deathmatch		: No
Difficulty Settings	: N/A

===========================================
=== 		Included Files				===
===========================================
compact.bsp
compact.map
compact.lit
readme.txt

===========================================
=== 		Construction				===
===========================================
Editor Used		: Trenchbroom 2021.1 win32
Known bugs		: 
Tested With		: quakespasm-0.94.2_win64 / 2021 Bethesda Rerelease

===========================================
=== 		Copyright Info				===
===========================================

Authors MAY use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.