===========================================
=== 		Details						===
===========================================
Title 				: Courtyard
Filename 			: courtyard.zip
Map name			: courtyard.bsp 
Release Date 		: 01/01/2021
Author 				: Addy / TheADrain
Twitter				: @adraindev
Additional Credits	: Aleksander "Khreathor" Marhall (prototype.zip) could not build without it <3

===========================================
=== 		Description					===
===========================================

Deathmatch map set in a spooky cathedral courtyard

This is my first map, I really hope you enjoy it :)
I would love any feedback on the design!

Thanks
~Addy 

===========================================
=== 		Play Info			===
===========================================
Primary Design		: 2-4 player Deathmatch
Single Player		: Player start only
Cooperative Play	: No
Difficulty Settings	: N/A

===========================================
=== 		Included Files				===
===========================================
courtyard.bsp
courtyard.map
readme.txt

===========================================
=== 		Construction				===
===========================================
Editor Used		: Trenchbroom 2021.1 win32
Known bugs		: 
Tested With		: quakespasm-0.94.2_win64 / 2021 Bethesda Rerelease

===========================================
=== 		Copyright Info				===
===========================================

Authors MAY use the contents of this file as a base for
modification or reuse.  Permissions have been obtained from original 
authors for any of their resources modified or included in this file.